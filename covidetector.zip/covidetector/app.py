from flask import Flask, render_template, request, jsonify
import numpy as np
import pandas as pd
import joblib
from tensorflow.keras.models import load_model

app = Flask(__name__)

# =========================
# Load model + scaler
# =========================
model = load_model("mlp_model.h5")
scaler = joblib.load("scaler.pkl")

# Try to read feature names from scaler (best, avoids ordering bugs)
try:
    input_columns = scaler.feature_names_in_.tolist()
except AttributeError:
    # Fallback – MUST match training columns exactly and in order
    input_columns = [
        'Fever', 'Tiredness', 'Dry-Cough', 'Difficulty-in-Breathing', 'Sore-Throat',
        'None_Sympton', 'Pains', 'Nasal-Congestion', 'Runny-Nose', 'Diarrhea', 'None_Experiencing',
        'Age_0-9', 'Age_10-19', 'Age_20-24', 'Age_25-59', 'Age_60+',
        'Gender_Female', 'Gender_Male', 'Gender_Transgender',
        'Severity_Mild', 'Severity_Moderate', 'Severity_None',
        'Contact_Dont-Know', 'Contact_No', 'Contact_Yes'
    ]


# =========================
# Routes
# =========================
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()

    # Build row in correct column order; missing keys default to 0
    row = {col: float(data.get(col, 0)) for col in input_columns}

    df = pd.DataFrame([row], columns=input_columns)

    # Scale and reshape for 1D-CNN: (batch, features, 1)
    scaled = scaler.transform(df)
    scaled = np.expand_dims(scaled, axis=2)

    # Predict
    prob = float(model.predict(scaled)[0][0])
    pred = 1 if prob >= 0.5 else 0

    return jsonify({
        "prediction": int(pred),
        "probability": prob
    })


if __name__ == "__main__":
    app.run(debug=True)
